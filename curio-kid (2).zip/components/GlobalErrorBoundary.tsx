import React, { Component, ErrorInfo, PropsWithChildren } from 'react';
import { ApiErrorDisplay } from './common';

export class GlobalErrorBoundary extends Component<PropsWithChildren, { hasError: boolean; error: Error | null }> {
  // FIX: Initialize state in the constructor for broader compatibility and to ensure 'this' context is correctly available.
  constructor(props: PropsWithChildren) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return <ApiErrorDisplay message={this.state.error?.message || 'An unknown error occurred.'} onDismiss={() => this.setState({ hasError: false, error: null })} />;
    }
    return this.props.children;
  }
}
