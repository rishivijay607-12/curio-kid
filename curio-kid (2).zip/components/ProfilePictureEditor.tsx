import React, { useState, useRef } from 'react';
import { ActionButton } from './common';

export const ProfilePictureEditor: React.FC<{
    imageUrl: string;
    onSave: (dataUrl: string) => void;
    onCancel: () => void;
}> = ({ imageUrl, onSave, onCancel }) => {
    const [zoom, setZoom] = useState(1);
    const [offset, setOffset] = useState({ x: 0, y: 0 });
    const [isDragging, setIsDragging] = useState(false);
    const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
    const imgRef = useRef<HTMLImageElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    const handleMouseDown = (e: React.MouseEvent) => {
        setIsDragging(true);
        setDragStart({ x: e.clientX - offset.x, y: e.clientY - offset.y });
    };

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!isDragging) return;
        setOffset({
            x: e.clientX - dragStart.x,
            y: e.clientY - dragStart.y,
        });
    };

    const handleMouseUp = () => {
        setIsDragging(false);
    };
    
    const handleMouseLeave = () => {
        setIsDragging(false);
    };

    const handleSave = () => {
        if (!imgRef.current || !canvasRef.current || !containerRef.current) return;

        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        const image = imgRef.current;
        const containerSize = containerRef.current.offsetWidth;
        canvas.width = containerSize;
        canvas.height = containerSize;
        
        const scaledWidth = image.naturalWidth * zoom;
        const scaledHeight = image.naturalHeight * zoom;

        const drawX = offset.x;
        const drawY = offset.y;

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(image, drawX, drawY, scaledWidth, scaledHeight);
        
        onSave(canvas.toDataURL('image/png'));
    };

    return (
        <div className="flex flex-col items-center p-4 bg-slate-800 rounded-lg">
            <p className="text-slate-300 mb-4">Adjust your new profile picture</p>
            <div
                ref={containerRef}
                className="w-64 h-64 rounded-full overflow-hidden border-4 border-cyan-500 relative cursor-move bg-slate-700"
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseLeave}
            >
                <img
                    ref={imgRef}
                    src={imageUrl}
                    className="absolute top-0 left-0"
                    style={{
                        transform: `scale(${zoom})`,
                        transformOrigin: 'top left',
                        left: `${offset.x}px`,
                        top: `${offset.y}px`,
                        width: 'auto',
                        height: 'auto',
                        maxWidth: 'none',
                        maxHeight: 'none',
                    }}
                    draggable="false"
                    crossOrigin="anonymous"
                />
            </div>
             <canvas ref={canvasRef} className="hidden" />

            <div className="w-full max-w-xs mt-4">
              <label htmlFor="zoom" className="block text-sm font-medium text-slate-400">Zoom</label>
              <input
                  id="zoom"
                  type="range"
                  min="0.5"
                  max="3"
                  step="0.01"
                  value={zoom}
                  onChange={(e) => setZoom(parseFloat(e.target.value))}
                  className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
              />
            </div>

            <div className="flex justify-center gap-4 mt-6">
                <ActionButton onClick={handleSave}>Save</ActionButton>
                <button onClick={onCancel} className="px-6 py-3 font-bold text-lg rounded-lg bg-slate-600 text-white hover:bg-slate-500 transition-colors">Cancel</button>
            </div>
        </div>
    );
};
