import React from 'react';
import { Grade, User, Badge, BadgeType, HistoricalScientist, UserStats } from './types';

export const USERS_KEY = 'theBookOfCuriosity/users';
export const CURRENT_USER_ID_KEY = 'theBookOfCuriosity/currentUserId';
export const LEADERBOARD_KEY = 'theBookOfCuriosity/leaderboard';
export const ACTIVITY_LOG_KEY = 'theBookOfCuriosity/activityLog';
export const getSavedQuizKey = (userId: string) => `theBookOfCuriosity/savedQuiz_${userId}`;

export const GITHUB_USERNAME = 'rishivijay123-12';
export const GITHUB_PROFILE_URL = 'https://github.com/rishivijay123-12';

export const CHAPTERS_BY_GRADE: Record<Grade, string[]> = {
  6: [ "The Wonderful World of Science", "Diversity in the Living World", "Mindful Eating: A Path to a Healthy Body", "Exploring Magnets", "Measurement of Length and Motion", "Materials Around Us", "Temperature and its Measurement", "A Journey through States of Water", "Methods of Separation in Everyday Life", "Living Creatures: Exploring their Characteristics", "Nature’s Treasures", "Beyond Earth", ],
  7: [ "The Ever-Evolving World of Science", "Exploring Substances: Acidic, Basic, and Neutral", "Electricity: Circuits and their Components", "The World of Metals and Non-metals", "Changes Around Us: Physical and Chemical", "Adolescence: A Stage of Growth and Change", "Heat Transfer in Nature", "Measurement of Time and Motion", "Life Processes in Animals", "Life Processes in Plants", "Light: Shadows and Reflections", "Earth, Moon, and the Sun", ],
  8: [ "Exploring the Investigative World of Science", "The Invisible Living World: Beyond Our Naked Eye", "Health: The Ultimate Treasure", "Electricity: Magnetic and Heating Effects", "Exploring Forces", "Pressure, Winds, Storms, and Cyclones", "Particulate Nature of Matter", "Nature of Matter: Elements, Compounds, and Mixtures", "The Amazing World of Solutes, Solvents, and Solutions", "Light: Mirrors and Lenses", "Keeping Time with the Skies", "How Nature Works in Harmony", "Our Home: Earth, a Unique Life Sustaining Planet", ],
  9: [ "MATTER IN OUR SURROUNDINGS", "IS MATTER AROUND US PURE?", "ATOMS AND MOLECULES", "STRUCTURE OF THE ATOM", "THE FUNDAMENTAL UNIT OF LIFE", "TISSUES", "MOTION", "FORCE AND LAWS OF MOTION", "GRAVITATION", "WORK AND ENERGY", "SOUND", "IMPROVEMENT IN FOOD RESOURCES", ],
  10: [ "Chemical Reactions and Equations", "Acids, Bases and Salts", "Metals and Non-metals", "Carbon and its Compounds", "Life Processes", "Control and Coordination", "How do Organisms Reproduce?", "Heredity", "Light – Reflection and Refraction", "The Human Eye and the Colourful World", "Electricity", "Magnetic Effects of Electric Current", "Our Environment", ],
};

// FIX: Replaced JSX with React.createElement to be compatible with .ts files.
export const BADGE_DEFINITIONS: Record<BadgeType, Omit<Badge, 'dateEarned' | 'id'> & { criteria: (stats: UserStats, context: { score: number; questionCount: number; topic: string }) => boolean; icon: React.ReactNode; }> = {
    [BadgeType.QUIZ_NOVICE]: {
        name: 'First Steps',
        description: 'Completed your first quiz. The journey of a thousand miles begins with a single step!',
        icon: React.createElement('svg', { xmlns: "http://www.w3.org/2000/svg", className: "h-full w-full", viewBox: "0 0 20 20", fill: "currentColor" }, React.createElement('path', { fillRule: "evenodd", d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z", clipRule: "evenodd" })),
        criteria: (stats) => stats.quizzesCompleted === 1,
    },
    [BadgeType.QUIZ_ADEPT]: {
        name: 'Quiz Adept',
        description: 'Completed 10 quizzes. You\'re getting the hang of this!',
        icon: React.createElement('svg', { xmlns: "http://www.w3.org/2000/svg", className: "h-full w-full", viewBox: "0 0 20 20", fill: "currentColor" }, React.createElement('path', { d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" })),
        criteria: (stats) => stats.quizzesCompleted === 10,
    },
    [BadgeType.QUIZ_MASTER]: {
        name: 'Quiz Master',
        description: 'Completed 25 quizzes. A true master of curiosity!',
        icon: React.createElement('svg', { xmlns: "http://www.w3.org/2000/svg", className: "h-full w-full", viewBox: "0 0 20 20", fill: "currentColor" }, React.createElement('path', { d: "M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zm4.24 16L12 15.45 7.77 18l1.12-4.81-3.73-3.23 4.92-.42L12 5l1.92 4.54 4.92.42-3.73 3.23L16.23 18z" })),
        criteria: (stats) => stats.quizzesCompleted >= 25,
    },
    [BadgeType.PERFECT_SCORE]: {
        name: 'Perfectionist',
        description: 'Achieved a perfect 100% score on a quiz.',
        icon: React.createElement('svg', { xmlns: "http://www.w3.org/2000/svg", className: "h-full w-full", viewBox: "0 0 20 20", fill: "currentColor" }, React.createElement(React.Fragment, null, React.createElement('path', { fillRule: "evenodd", d: "M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zM10 15.5a5.5 5.5 0 100-11 5.5 5.5 0 000 11z", clipRule: "evenodd" }), React.createElement('path', { d: "M10 12.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z" }))),
        criteria: (stats, context) => context.score === context.questionCount && context.questionCount > 0,
    },
    [BadgeType.TOPIC_ACE]: {
        name: 'Topic Ace',
        description: 'Achieved over 80% accuracy in a topic after at least 3 quizzes.',
        icon: React.createElement('svg', { xmlns: "http://www.w3.org/2000/svg", className: "h-full w-full", viewBox: "0 0 20 20", fill: "currentColor" }, React.createElement('path', { d: "M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z" })),
        criteria: (stats, context) => {
            const perf = stats.topicPerformance[context.topic];
            if (!perf || perf.total < (context.questionCount * 3)) return false; // Need at least 3 quizzes worth of questions
            return (perf.correct / perf.total) > 0.8;
        }
    },
};

export const DEFAULT_ADMIN_USER: User = {
    id: 'admin_user_001',
    username: 'rishivijay123-12',
    password: 'password',
    isAdmin: true,
    stats: {
        quizzesCompleted: 0,
        quizzesAttempted: 0,
        topicsMastered: [],
        totalScorePoints: 0,
        totalQuestionsAnswered: 0,
        timeSpentLearningInSeconds: 0,
        topicPerformance: {},
        badges: [],
    },
};

export const HISTORICAL_SCIENTISTS: HistoricalScientist[] = [
    {
        id: 'marie_curie',
        name: 'Marie Curie',
        era: '1867-1934',
        field: 'Physics & Chemistry',
        systemInstruction: "You are a simulation of Marie Curie. You are passionate, determined, and brilliant. Speak about your research on radioactivity, the challenges you faced as a woman in science, and the importance of perseverance. Maintain a formal yet inspiring tone. Do not break character.",
        imageUrl: 'https://api.dicebear.com/8.x/pixel-art/svg?seed=Marie%20Curie'
    },
    {
        id: 'albert_einstein',
        name: 'Albert Einstein',
        era: '1879-1955',
        field: 'Theoretical Physics',
        systemInstruction: "You are a simulation of Albert Einstein. You are imaginative, curious, and a bit eccentric. Explain your theories of relativity in simple terms using thought experiments. Discuss the nature of space, time, and gravity. Encourage curiosity and questioning everything. Maintain a friendly, avuncular tone. Do not break character.",
        imageUrl: 'https://api.dicebear.com/8.x/pixel-art/svg?seed=Albert%20Einstein'
    },
    {
        id: 'isaac_newton',
        name: 'Isaac Newton',
        era: '1643-1727',
        field: 'Physics & Mathematics',
        systemInstruction: "You are a simulation of Sir Isaac Newton. You are formal, serious, and deeply intellectual. Discuss your laws of motion, universal gravitation, and your work on optics. You can be a bit stern, but you have a profound respect for the order of the natural world. Do not break character.",
        imageUrl: 'https://api.dicebear.com/8.x/pixel-art/svg?seed=Isaac%20Newton'
    },
    {
        id: 'cv_raman',
        name: 'C. V. Raman',
        era: '1888-1970',
        field: 'Physics',
        systemInstruction: "You are a simulation of Sir C. V. Raman. You are proud of your Indian heritage and immensely curious about the natural world, especially light. Speak passionately about the Raman Effect, the scattering of light, and why the sea appears blue. Encourage students to observe the world around them with a scientific eye. Do not break character.",
        imageUrl: 'https://api.dicebear.com/8.x/pixel-art/svg?seed=CV%20Raman'
    },
    {
        id: 'aryabhata',
        name: 'Aryabhata',
        era: 'c. 476–c. 550 CE',
        field: 'Mathematics & Astronomy',
        systemInstruction: "You are a simulation of the ancient Indian mathematician and astronomer, Aryabhata. You are precise, logical, and ahead of your time. Speak about your contributions like the place value system, the approximation of pi, and your theories on the heliocentric model and eclipses. Use simple language to explain complex mathematical and astronomical concepts. Do not break character.",
        imageUrl: 'https://api.dicebear.com/8.x/pixel-art/svg?seed=Aryabhata'
    }
];
