import React from 'react';
import { ActivityLog } from '../types';
import { Blob } from "@google/genai";

export const generateUniqueId = (): string => Date.now().toString(36) + Math.random().toString(36).substring(2);

export const timeAgo = (dateString: string): string => {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.round((now.getTime() - date.getTime()) / 1000);
    const minutes = Math.round(seconds / 60);
    const hours = Math.round(minutes / 60);
    const days = Math.round(hours / 24);

    if (seconds < 60) return `${seconds}s ago`;
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
};

// FIX: Replaced JSX with React.createElement to be compatible with .ts files.
export const formatLogMessage = (log: ActivityLog): React.ReactNode => {
    const username = React.createElement('span', { className: "font-semibold text-cyan-400" }, log.username);
    switch (log.type) {
        case 'USER_REGISTERED': return React.createElement(React.Fragment, null, username, " created a new account.");
        case 'USER_LOGIN': return React.createElement(React.Fragment, null, username, " logged in.");
        case 'USER_LOGOUT': return React.createElement(React.Fragment, null, username, " logged out.");
        case 'QUIZ_STARTED': return React.createElement(React.Fragment, null, username, ` started a ${log.details.difficulty} quiz on "${log.details.topic}" (Grade ${log.details.grade}).`);
        case 'QUIZ_COMPLETED': return React.createElement(React.Fragment, null, username, ` completed a quiz on "${log.details.topic}" with a score of ${log.details.score}/${log.details.questionCount}.`);
        case 'DOUBT_SOLVER_STARTED': return React.createElement(React.Fragment, null, username, ` started a doubt solver session for "${log.details.topic}" (Grade ${log.details.grade}).`);
        case 'VOICE_TUTOR_STARTED': return React.createElement(React.Fragment, null, username, ` started a voice tutor session for "${log.details.topic}" (Grade ${log.details.grade}).`);
        case 'WORKSHEET_GENERATED': return React.createElement(React.Fragment, null, username, ` generated a ${log.details.difficulty} worksheet on "${log.details.topic}".`);
        case 'NOTES_GENERATED': return React.createElement(React.Fragment, null, username, ` generated notes for "${log.details.topic}".`);
        case 'DEEP_DIVE_REQUESTED': return React.createElement(React.Fragment, null, username, ` requested a deep dive on "${log.details.topic}".`);
        case 'DIAGRAM_GENERATED': return React.createElement(React.Fragment, null, username, ` generated a diagram: "${log.details.description}".`);
        case 'BADGE_EARNED': return React.createElement(React.Fragment, null, username, ` earned the "${log.details.badgeName}" badge! ✨`);
        case 'VIRTUAL_LAB_STARTED': return React.createElement(React.Fragment, null, username, ` started a virtual lab experiment: "${log.details.prompt}".`);
        case 'REAL_WORLD_EXAMPLE_GENERATED': return React.createElement(React.Fragment, null, username, ` explored real-world examples for "${log.details.topic}".`);
        case 'HISTORICAL_CHAT_STARTED': return React.createElement(React.Fragment, null, username, ` started a chat with ${log.details.scientistName}.`);
        case 'AI_STORY_WEAVER_USED': return React.createElement(React.Fragment, null, username, ` created a story with the prompt: "${log.details.prompt}".`);
        default: return React.createElement(React.Fragment, null, "An unknown activity by ", username, " occurred.");
    }
};

export const encode = (bytes: Uint8Array): string => {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

export const decode = (base64: string): Uint8Array => {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

export const decodeAudioData = async (
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> => {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
};

export const createBlob = (data: Float32Array): Blob => {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
};