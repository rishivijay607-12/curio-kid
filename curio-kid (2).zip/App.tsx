import React, { useState, useRef, Suspense, useCallback, useEffect, lazy } from 'react';
import { GoogleGenAI, Chat, Modality, Blob, LiveServerMessage } from "@google/genai";
import { 
    GameState, AppMode, Grade, Difficulty, Language, QuizQuestion, NoteSection, 
    DiagramIdea, Diagram, ChatMessage, User, Badge, LeaderboardEntry, ActivityLog, 
    SavedQuizState, TranscriptPart, TutorStatus, VirtualLabStep, RealWorldExample, HistoricalScientist 
} from './types';
import { 
    USERS_KEY, CURRENT_USER_ID_KEY, LEADERBOARD_KEY, ACTIVITY_LOG_KEY, getSavedQuizKey, 
    CHAPTERS_BY_GRADE, BADGE_DEFINITIONS, DEFAULT_ADMIN_USER, HISTORICAL_SCIENTISTS 
} from './constants';
import { 
    initializeAiClient, getAiClient, generateDiagramIdeas, generateDiagramImage, generateQuizQuestions, 
    generateNotes, generateConceptExplanation, generateStudyPlan, generateVirtualLabSteps, 
    generateRealWorldExamples, generateAIStory 
} from './services/geminiService';
import { useLocalStorage } from './hooks/useLocalStorage';
import { generateUniqueId, timeAgo, formatLogMessage, encode, decode, decodeAudioData, createBlob } from './utils/helpers';
import { GlobalErrorBoundary } from './components/GlobalErrorBoundary';
import { ProfilePictureEditor } from './components/ProfilePictureEditor';
import { 
    LoadingSpinner, FullScreenLoader, ApiErrorDisplay, PageHeader, ActionButton, SelectionButton, 
    HomeButton, LogoutButton, HomeScreenAtomIcon, FeatureCard, Modal 
} from './components/common';

const Markdown = lazy(() => import('https://esm.sh/react-markdown@9?bundle'));
const remarkGfm = lazy(() => import('https://esm.sh/remark-gfm@4?bundle'));

const App: React.FC = () => {
    // FIX: Reordered state to initialize gameState based on whether a user is logged in.
    // User Management
    const [users, setUsers] = useLocalStorage<User[]>(USERS_KEY, []);
    const [currentUserId, setCurrentUserId] = useLocalStorage<string | null>(CURRENT_USER_ID_KEY, null);
    const currentUser = users.find(u => u.id === currentUserId) || null;

    // Game State
    const [gameState, setGameState] = useState<GameState>(currentUser ? GameState.HOME_SCREEN : GameState.LOGIN_SCREEN);
    const [appMode, setAppMode] = useState<AppMode | null>(null);

    // Selections
    const [grade, setGrade] = useState<Grade | null>(null);
    const [topic, setTopic] = useState<string | null>(null);
    const [language, setLanguage] = useState<Language>('English');
    const [difficulty, setDifficulty] = useState<Difficulty | null>(null);
    const [questionCount, setQuestionCount] = useState<number>(10);
    const [timePerQuestion, setTimePerQuestion] = useState<number>(30); // 0 for unlimited
    
    // Data & Loading
    const [isLoading, setIsLoading] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState('');
    const [apiError, setApiError] = useState<string | null>(null);
    const [questions, setQuestions] = useState<QuizQuestion[]>([]);
    const [notes, setNotes] = useState<NoteSection[]>([]);
    const [conceptExplanation, setConceptExplanation] = useState<string>('');
    const [diagramIdeas, setDiagramIdeas] = useState<DiagramIdea[]>([]);
    const [generatedDiagram, setGeneratedDiagram] = useState<Diagram | null>(null);
    const [inputPrompt, setInputPrompt] = useState('');
    
    // Quiz State
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [userAnswers, setUserAnswers] = useState<(string | null)[]>([]);
    const [score, setScore] = useState(0);
    const [timeLeft, setTimeLeft] = useState(0);
    
    // Doubt Solver State
    const [doubtSolverChat, setDoubtSolverChat] = useState<Chat | null>(null);
    const [doubtSolverMessages, setDoubtSolverMessages] = useState<ChatMessage[]>([]);
    const [isThinking, setIsThinking] = useState(false);

    // Voice Tutor State
    const [tutorStatus, setTutorStatus] = useState<TutorStatus>('CONNECTING');
    const [transcript, setTranscript] = useState<TranscriptPart[]>([]);
    const liveSessionRef = useRef<any>(null); // Using `any` for the session promise/object
    const audioResourcesRef = useRef<{
        stream: MediaStream | null;
        inputAudioContext: AudioContext | null;
        outputAudioContext: AudioContext | null;
        sources: Set<AudioBufferSourceNode>;
        scriptProcessor: ScriptProcessorNode | null;
    }>({ stream: null, inputAudioContext: null, outputAudioContext: null, sources: new Set(), scriptProcessor: null });

    // New Features State
    const [studyPlan, setStudyPlan] = useState<string | null>(null);
    const [virtualLabSteps, setVirtualLabSteps] = useState<VirtualLabStep[]>([]);
    const [realWorldExamples, setRealWorldExamples] = useState<RealWorldExample[]>([]);
    const [selectedScientist, setSelectedScientist] = useState<HistoricalScientist | null>(null);
    const [historicalChat, setHistoricalChat] = useState<Chat | null>(null);
    const [historicalChatMessages, setHistoricalChatMessages] = useState<ChatMessage[]>([]);
    const [aiStory, setAiStory] = useState('');


    // User Authentication State
    const [showRegister, setShowRegister] = useState(false);
    const [usernameInput, setUsernameInput] = useState('');
    const [passwordInput, setPasswordInput] = useState('');
    const [authError, setAuthError] = useState('');
    const [editingProfilePic, setEditingProfilePic] = useState<string | null>(null);

    // Gamification & Logging
    const [leaderboard, setLeaderboard] = useLocalStorage<LeaderboardEntry[]>(LEADERBOARD_KEY, []);
    const [newBadges, setNewBadges] = useState<Badge[]>([]);
    const [activityLog, setActivityLog] = useLocalStorage<ActivityLog[]>(ACTIVITY_LOG_KEY, []);
    const [showBadgeModal, setShowBadgeModal] = useState(false);

    // ====================================================================================
    // Effects
    // ====================================================================================

    // Initialize AI Client on startup
    useEffect(() => {
        try {
            initializeAiClient();
        } catch (error) {
            console.error("Failed to initialize AI client:", error);
            setApiError(error instanceof Error ? error.message : "An unknown error occurred during AI initialization.");
        }
    }, []);

    // Initialize default users if none exist
    useEffect(() => {
        if (users.length === 0) {
            setUsers([DEFAULT_ADMIN_USER]);
        }
    }, [users, setUsers]);

    // Save/Load Quiz State
    useEffect(() => {
        if (currentUser && gameState === GameState.QUIZ_IN_PROGRESS) {
            const stateToSave: SavedQuizState = {
                gameState, appMode: 'quiz', grade: grade!, topic: topic!, difficulty: difficulty!,
                timePerQuestion, questions, userAnswers, currentQuestionIndex,
            };
            localStorage.setItem(getSavedQuizKey(currentUser.id), JSON.stringify(stateToSave));
        }
    }, [gameState, currentQuestionIndex, userAnswers, currentUser, appMode, grade, topic, difficulty, timePerQuestion, questions]);

    useEffect(() => {
        if (currentUser) {
            const savedStateJSON = localStorage.getItem(getSavedQuizKey(currentUser.id));
            if (savedStateJSON) {
                const savedState: SavedQuizState = JSON.parse(savedStateJSON);
                if (window.confirm("You have an unfinished quiz. Would you like to resume?")) {
                    setGameState(savedState.gameState);
                    setAppMode(savedState.appMode);
                    setGrade(savedState.grade);
                    setTopic(savedState.topic);
                    setDifficulty(savedState.difficulty);
                    setTimePerQuestion(savedState.timePerQuestion);
                    setQuestions(savedState.questions);
                    setUserAnswers(savedState.userAnswers);
                    setCurrentQuestionIndex(savedState.currentQuestionIndex);
                    if(savedState.timePerQuestion > 0) {
                        setTimeLeft(savedState.timePerQuestion);
                    }
                } else {
                    localStorage.removeItem(getSavedQuizKey(currentUser.id));
                }
            }
        }
    }, [currentUserId]); // Run only when user logs in

    // ====================================================================================
    // Logging and Gamification
    // ====================================================================================

    const addLogEntry = useCallback((type: string, details: Record<string, any>) => {
        if (!currentUser) return;
        const newLog: ActivityLog = {
            id: generateUniqueId(),
            userId: currentUser.id,
            username: currentUser.username,
            timestamp: new Date().toISOString(),
            type,
            details,
        };
        setActivityLog(prev => [newLog, ...prev.slice(0, 49)]); // Keep last 50 entries
    }, [currentUser, setActivityLog]);

    const updateUserStats = useCallback((updateFn: (stats: User['stats']) => User['stats']) => {
        if (!currentUserId) return;
        setUsers(prevUsers =>
            prevUsers.map(user =>
                user.id === currentUserId
                    ? { ...user, stats: updateFn(user.stats) }
                    : user
            )
        );
    }, [currentUserId, setUsers]);
    
    const awardBadges = useCallback((score: number, questionCount: number, topic: string) => {
        if (!currentUser) return [];

        const earned: Badge[] = [];
        const currentStats = currentUser.stats;
        
        const updatedStats: User['stats'] = {
            ...currentStats,
            quizzesCompleted: currentStats.quizzesCompleted + 1,
            quizzesAttempted: currentStats.quizzesAttempted + 1,
            topicPerformance: {
                ...currentStats.topicPerformance,
                [topic]: {
                    correct: (currentStats.topicPerformance[topic]?.correct || 0) + score,
                    total: (currentStats.topicPerformance[topic]?.total || 0) + questionCount,
                }
            }
        };

        for (const badgeType in BADGE_DEFINITIONS) {
            const badgeKey = badgeType as keyof typeof BADGE_DEFINITIONS;
            const hasBadge = currentUser.stats.badges.some(b => b.id === badgeKey);
            if (!hasBadge) {
                const def = BADGE_DEFINITIONS[badgeKey];
                if (def.criteria(updatedStats, { score, questionCount, topic })) {
                    const newBadge: Badge = {
                        id: badgeKey,
                        name: def.name,
                        description: def.description,
                        dateEarned: new Date().toISOString(),
                    };
                    earned.push(newBadge);
                }
            }
        }
        
        if(earned.length > 0) {
            setNewBadges(earned);
            setShowBadgeModal(true);
            earned.forEach(badge => addLogEntry('BADGE_EARNED', { badgeName: badge.name }));
        }

        return earned;
    }, [currentUser, addLogEntry]);

    const updateLeaderboard = useCallback((username: string, pointsToAdd: number, profilePictureUrl?: string) => {
        setLeaderboard(prev => {
            const userIndex = prev.findIndex(e => e.username === username);
            let newLeaderboard = [...prev];
            if (userIndex > -1) {
                newLeaderboard[userIndex].score += pointsToAdd;
                if (profilePictureUrl) {
                    newLeaderboard[userIndex].profilePictureUrl = profilePictureUrl;
                }
            } else if (currentUser) {
                newLeaderboard.push({ userId: currentUser.id, username, score: pointsToAdd, profilePictureUrl });
            }
            return newLeaderboard.sort((a, b) => b.score - a.score).slice(0, 20);
        });
    }, [setLeaderboard, currentUser]);


    // ====================================================================================
    // API Call Handlers
    // ====================================================================================

    const withApiErrorHandler = async <T,>(apiCall: () => Promise<T>): Promise<T | null> => {
        try {
            const result = await apiCall();
            setApiError(null);
            return result;
        } catch (error) {
            console.error("API Error:", error);
            const message = error instanceof Error ? error.message : "An unexpected error occurred.";
            if (message.includes('API key not valid')) {
                setApiError("The provided API Key is not valid. Please check the configuration.");
            } else {
                 setApiError(message);
            }
            setIsLoading(false);
            return null;
        }
    };

    const handleGenerateDiagramIdeas = async () => {
        if (!topic || !grade) return;
        setIsLoading(true);
        setLoadingMessage(`Brainstorming diagram ideas for "${topic}"...`);
        const ideas = await withApiErrorHandler(() => generateDiagramIdeas(topic, grade));
        if (ideas) {
            setDiagramIdeas(ideas.map(idea => ({ ...idea, id: generateUniqueId() })));
            setGameState(GameState.DIAGRAM_IDEAS_SELECTION);
        }
        setIsLoading(false);
    };

    const handleGenerateDiagram = async (idea: DiagramIdea) => {
        setIsLoading(true);
        setLoadingMessage(`Generating diagram: "${idea.description}"...`);
        const image = await withApiErrorHandler(() => generateDiagramImage(idea.prompt));
        if (image) {
            setGeneratedDiagram({ ...idea, image });
            setGameState(GameState.DIAGRAM_GENERATOR);
            addLogEntry('DIAGRAM_GENERATED', { description: idea.description });
        }
        setIsLoading(false);
    };

    const handleGenerateQuiz = async (selectedDifficulty: Difficulty, selectedCount: number, selectedTime: number, mode: AppMode) => {
        if (!topic || !grade) return;
        setIsLoading(true);
        setLoadingMessage(`Generating ${selectedDifficulty} ${mode}...`);
        const questionsResult = await withApiErrorHandler(() => generateQuizQuestions(topic, grade, selectedDifficulty, selectedCount, mode));
        if (questionsResult) {
            setQuestions(questionsResult);
            setUserAnswers(new Array(questionsResult.length).fill(null));
            setCurrentQuestionIndex(0);
            setScore(0);
            
            if (mode === 'quiz') {
                setDifficulty(selectedDifficulty);
                setQuestionCount(selectedCount);
                setTimePerQuestion(selectedTime);
                if (selectedTime > 0) {
                    setTimeLeft(selectedTime);
                }
                setGameState(GameState.QUIZ_IN_PROGRESS);
                addLogEntry('QUIZ_STARTED', { topic, grade, difficulty: selectedDifficulty });
                updateUserStats(stats => ({...stats, quizzesAttempted: stats.quizzesAttempted + 1 }));

            } else { // worksheet
                setGameState(GameState.WORKSHEET_DISPLAY);
                addLogEntry('WORKSHEET_GENERATED', { topic, grade, difficulty: selectedDifficulty });
            }
        }
        setIsLoading(false);
    };

    const handleGenerateNotes = async () => {
        if (!topic || !grade) return;
        setIsLoading(true);
        setLoadingMessage(`Generating study notes for "${topic}"...`);
        const notesResult = await withApiErrorHandler(() => generateNotes(topic, grade));
        if (notesResult) {
            setNotes(notesResult);
            setGameState(GameState.NOTES_DISPLAY);
            addLogEntry('NOTES_GENERATED', { topic, grade });
        }
        setIsLoading(false);
    };

    const handleGenerateDeepDive = async () => {
        if (!topic || !grade) return;
        setIsLoading(true);
        setLoadingMessage(`Diving deep into "${topic}"...`);
        const explanation = await withApiErrorHandler(() => generateConceptExplanation(topic, grade));
        if (explanation) {
            setConceptExplanation(explanation);
            setGameState(GameState.CONCEPT_DEEP_DIVE);
            addLogEntry('DEEP_DIVE_REQUESTED', { topic, grade });
        }
        setIsLoading(false);
    };

    // ====================================================================================
    // State Transitions & App Logic
    // ====================================================================================

    const resetSelections = () => {
        setGrade(null);
        setTopic(null);
        setAppMode(null);
        setDifficulty(null);
        setQuestionCount(10);
        setTimePerQuestion(30);
        setQuestions([]);
        setNotes([]);
        setConceptExplanation('');
        setDiagramIdeas([]);
        setGeneratedDiagram(null);
        setDoubtSolverMessages([]);
        setDoubtSolverChat(null);
        setVirtualLabSteps([]);
        setRealWorldExamples([]);
        setSelectedScientist(null);
        setHistoricalChat(null);
        setHistoricalChatMessages([]);
        setAiStory('');
        setInputPrompt('');
    };

    const goToHome = () => {
        resetSelections();
        setGameState(GameState.HOME_SCREEN);
    };

    const selectGrade = (selectedGrade: Grade) => {
        setGrade(selectedGrade);
        setGameState(GameState.TOPIC_SELECTION);
    };

    const startAppMode = (mode: AppMode) => {
        setAppMode(mode);
        switch (mode) {
            case 'profile':
                if(currentUser?.stats && currentUser.stats.quizzesCompleted > 0) {
                    generateAndSetStudyPlan();
                }
                setGameState(GameState.USER_PROFILE);
                break;
            case 'admin':
                setGameState(GameState.ADMIN_PANEL);
                break;
            case 'leaderboard':
                setGameState(GameState.LEADERBOARD);
                break;
            case 'virtual_lab':
                setGameState(GameState.VIRTUAL_LAB_INPUT);
                break;
             case 'historical_chat':
                setGameState(GameState.HISTORICAL_CHAT_SELECTION);
                break;
            case 'ai_story_weaver':
                setGameState(GameState.AI_STORY_WEAVER_INPUT);
                break;
            default:
                setGameState(GameState.GRADE_SELECTION);
                break;
        }
    };
    
    const handleAnswer = useCallback((answer: string | null) => {
        const newAnswers = [...userAnswers];
        newAnswers[currentQuestionIndex] = answer;
        setUserAnswers(newAnswers);

        setTimeout(() => {
            if (currentQuestionIndex < questions.length - 1) {
                setCurrentQuestionIndex(prev => prev + 1);
                if (timePerQuestion > 0) {
                    setTimeLeft(timePerQuestion);
                }
            } else {
                let finalScore = 0;
                newAnswers.forEach((ans, index) => {
                    if (ans === questions[index].answer) {
                        finalScore++;
                    }
                });
                setScore(finalScore);
                setGameState(GameState.QUIZ_SCORE);

                if (currentUser && topic) {
                    const earnedBadges = awardBadges(finalScore, questions.length, topic);
                    updateUserStats(stats => {
                        const topicPerf = stats.topicPerformance[topic] || { correct: 0, total: 0 };
                        return {
                            ...stats,
                            quizzesCompleted: stats.quizzesCompleted + 1,
                            totalScorePoints: stats.totalScorePoints + finalScore,
                            totalQuestionsAnswered: stats.totalQuestionsAnswered + questions.length,
                            topicPerformance: {
                                ...stats.topicPerformance,
                                [topic]: {
                                    correct: topicPerf.correct + finalScore,
                                    total: topicPerf.total + questions.length,
                                }
                            },
                            badges: [...stats.badges, ...earnedBadges],
                        };
                    });
                    updateLeaderboard(currentUser.username, finalScore, currentUser.profilePictureUrl);
                    addLogEntry('QUIZ_COMPLETED', { topic, score: finalScore, questionCount: questions.length });
                    localStorage.removeItem(getSavedQuizKey(currentUser.id));
                }
            }
        }, 500);
    }, [userAnswers, currentQuestionIndex, questions, timePerQuestion, currentUser, topic, awardBadges, updateUserStats, updateLeaderboard, addLogEntry]);

    // Quiz Timer Effect
    useEffect(() => {
        if (gameState !== GameState.QUIZ_IN_PROGRESS || timePerQuestion === 0) {
            return;
        }
        if (timeLeft <= 0) {
            handleAnswer(null); 
            return;
        }
        const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
        return () => clearInterval(timer);
    }, [gameState, timeLeft, timePerQuestion, handleAnswer]);


    const selectTopic = (selectedTopic: string) => {
        setTopic(selectedTopic);
        switch (appMode) {
            case 'diagram': handleGenerateDiagramIdeas(); break;
            case 'doubt_solver': setGameState(GameState.LANGUAGE_SELECTION); break;
            case 'quiz': setGameState(GameState.QUIZ_DIFFICULTY_SELECTION); break;
            case 'worksheet': setGameState(GameState.WORKSHEET_DIFFICULTY_SELECTION); break;
            case 'notes': handleGenerateNotes(); break;
            case 'deep_dive': handleGenerateDeepDive(); break;
            case 'voice_tutor': startVoiceTutor(); break;
            case 'real_world_connections': handleGenerateRealWorldExamples(); break;
            default: goToHome();
        }
    };
    
    const startDoubtSolver = (lang: Language) => {
        if (!topic || !grade) return;
        setLanguage(lang);
        setIsLoading(true);
        setLoadingMessage('Initializing Doubt Solver...');

        let systemInstruction = `You are a friendly and patient AI Tutor called 'Curio'. Your user is a Grade ${grade} student in India studying the chapter "${topic}". Your primary goal is to help them understand concepts and solve their doubts. Follow these rules strictly:\n1. Keep your explanations simple, clear, and directly related to the student's question and the chapter topic.\n2. Do not answer questions outside the scope of this topic.\n3. If the student asks an unrelated question, gently guide them back to the topic.\n4. Encourage the student and praise them for asking good questions.\n5. Use analogies and simple examples relevant to an Indian context.`;

        if (lang !== 'English') {
            const secondLang = lang.split('+')[1];
            systemInstruction += `\n6. You must reply in a mix of English and ${secondLang} (Hinglish/Tanglish etc.). The user will type in English, but your response should be conversational and bilingual, like how a real teacher in India might speak. For example, instead of "That's a great question!", you might say "That's a great question! Chalo, let's break it down."`
        }
        
        try {
            const chat = getAiClient().chats.create({ model: 'gemini-2.5-flash', config: { systemInstruction } });
            setDoubtSolverChat(chat);
            setDoubtSolverMessages([{ role: 'model', text: `Hello! I'm Curio, your AI Tutor for "${topic}". What would you like to ask?` }]);
            setGameState(GameState.DOUBT_SOLVER);
            addLogEntry('DOUBT_SOLVER_STARTED', { topic, grade });
        } catch(e) {
            setApiError(e instanceof Error ? e.message : 'Failed to start chat.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const sendDoubtSolverMessage = async (text: string) => {
        if (!doubtSolverChat || isThinking) return;
        setIsThinking(true);
        setDoubtSolverMessages(prev => [...prev, { role: 'user', text }]);
        
        try {
            const response = await doubtSolverChat.sendMessage({ message: text });
            setDoubtSolverMessages(prev => [...prev, { role: 'model', text: response.text }]);
        } catch (error) {
            console.error("Doubt Solver Error:", error);
            setDoubtSolverMessages(prev => [...prev, { role: 'model', text: "Sorry, I encountered an error. Please try asking again." }]);
        } finally {
            setIsThinking(false);
        }
    };
    
    // ====================================================================================
    // New Feature Handlers
    // ====================================================================================

    const generateAndSetStudyPlan = async () => {
      if (!currentUser) return;
      const plan = await withApiErrorHandler(() => generateStudyPlan(currentUser.stats));
      if (plan) {
        setStudyPlan(plan);
      }
    };

    const handleGenerateVirtualLab = async () => {
        if (!inputPrompt) return;
        setIsLoading(true);
        setLoadingMessage(`Setting up your virtual experiment for: "${inputPrompt}"...`);
        addLogEntry('VIRTUAL_LAB_STARTED', { prompt: inputPrompt });
        const steps = await withApiErrorHandler(() => generateVirtualLabSteps(inputPrompt));
        if (steps) {
            const stepsWithImages: VirtualLabStep[] = [];
            for (let i = 0; i < steps.length; i++) {
                setLoadingMessage(`Generating visual for step ${i+1}/${steps.length}...`);
                const image = await withApiErrorHandler(() => generateDiagramImage(steps[i].imagePrompt));
                stepsWithImages.push({ ...steps[i], image: image || undefined });
            }
            setVirtualLabSteps(stepsWithImages);
            setGameState(GameState.VIRTUAL_LAB_DISPLAY);
        }
        setIsLoading(false);
    };

    const handleGenerateRealWorldExamples = async () => {
        if (!topic) return;
        setIsLoading(true);
        setLoadingMessage(`Finding real-world connections for "${topic}"...`);
        addLogEntry('REAL_WORLD_EXAMPLE_GENERATED', { topic });
        const examples = await withApiErrorHandler(() => generateRealWorldExamples(topic));
        if (examples) {
             const examplesWithImages: RealWorldExample[] = [];
            for (let i = 0; i < examples.length; i++) {
                setLoadingMessage(`Generating visual for example ${i+1}/${examples.length}...`);
                const image = await withApiErrorHandler(() => generateDiagramImage(examples[i].imagePrompt));
                examplesWithImages.push({ ...examples[i], image: image || undefined });
            }
            setRealWorldExamples(examplesWithImages);
            setGameState(GameState.REAL_WORLD_CONNECTIONS_DISPLAY);
        }
        setIsLoading(false);
    };

    const startHistoricalChat = (scientist: HistoricalScientist) => {
        setIsLoading(true);
        setLoadingMessage(`Connecting with ${scientist.name}...`);
        try {
            const chat = getAiClient().chats.create({ model: 'gemini-2.5-flash', config: { systemInstruction: scientist.systemInstruction } });
            setHistoricalChat(chat);
            setSelectedScientist(scientist);
            setHistoricalChatMessages([{ role: 'model', text: `Greetings. I am ${scientist.name}. What great mysteries of the universe shall we ponder today?` }]);
            setGameState(GameState.HISTORICAL_CHAT_SESSION);
            addLogEntry('HISTORICAL_CHAT_STARTED', { scientistName: scientist.name });
        } catch(e) {
            setApiError(e instanceof Error ? e.message : 'Failed to start historical chat.');
        } finally {
            setIsLoading(false);
        }
    };

    const sendHistoricalChatMessage = async (text: string) => {
        if (!historicalChat || isThinking) return;
        setIsThinking(true);
        setHistoricalChatMessages(prev => [...prev, { role: 'user', text }]);
        
        try {
            const response = await historicalChat.sendMessage({ message: text });
            setHistoricalChatMessages(prev => [...prev, { role: 'model', text: response.text }]);
        } catch (error) {
            console.error("Historical Chat Error:", error);
            setHistoricalChatMessages(prev => [...prev, { role: 'model', text: "I seem to be lost in thought... perhaps you could rephrase your question?" }]);
        } finally {
            setIsThinking(false);
        }
    };

    const handleGenerateAIStory = async () => {
        if(!inputPrompt) return;
        setIsLoading(true);
        setLoadingMessage(`Weaving a scientific tale about "${inputPrompt}"...`);
        addLogEntry('AI_STORY_WEAVER_USED', { prompt: inputPrompt });
        const story = await withApiErrorHandler(() => generateAIStory(inputPrompt));
        if(story) {
            setAiStory(story);
            setGameState(GameState.AI_STORY_WEAVER_DISPLAY);
        }
        setIsLoading(false);
    };

    // ====================================================================================
    // Voice Tutor Logic
    // ====================================================================================
    
    const stopVoiceTutor = useCallback(() => {
        const resources = audioResourcesRef.current;
        if (liveSessionRef.current) {
            liveSessionRef.current.then((session: any) => session.close());
            liveSessionRef.current = null;
        }
        if (resources.stream) {
            resources.stream.getTracks().forEach(track => track.stop());
            resources.stream = null;
        }
        if (resources.scriptProcessor) {
            resources.scriptProcessor.disconnect();
            resources.scriptProcessor = null;
        }
        if (resources.inputAudioContext && resources.inputAudioContext.state !== 'closed') {
            resources.inputAudioContext.close();
            resources.inputAudioContext = null;
        }
        if (resources.outputAudioContext && resources.outputAudioContext.state !== 'closed') {
            resources.outputAudioContext.close();
            resources.outputAudioContext = null;
        }
        resources.sources.forEach(source => source.stop());
        resources.sources.clear();

        setTutorStatus('CONNECTING');
        setTranscript([]);
    }, []);

    const startVoiceTutor = useCallback(async () => {
        if (!topic || !grade) return;
        addLogEntry('VOICE_TUTOR_STARTED', { topic, grade });
        setGameState(GameState.VOICE_TUTOR_SESSION);
        setTutorStatus('CONNECTING');
        setTranscript([]);

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            audioResourcesRef.current.stream = stream;

            const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            audioResourcesRef.current.inputAudioContext = inputAudioContext;
            audioResourcesRef.current.outputAudioContext = outputAudioContext;

            let nextStartTime = 0;
            const sources = audioResourcesRef.current.sources;

            const sessionPromise = getAiClient().live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                callbacks: {
                    onopen: () => {
                        setTutorStatus('LISTENING');
                        const source = inputAudioContext.createMediaStreamSource(stream);
                        const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
                        audioResourcesRef.current.scriptProcessor = scriptProcessor;

                        scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            const pcmBlob = createBlob(inputData);
                            sessionPromise.then((session) => {
                                session.sendRealtimeInput({ media: pcmBlob });
                            });
                        };
                        source.connect(scriptProcessor);
                        scriptProcessor.connect(inputAudioContext.destination);
                    },
                    onmessage: async (message: LiveServerMessage) => {
                        if (message.serverContent?.inputTranscription) {
                            const text = message.serverContent.inputTranscription.text;
                            setTranscript(prev => {
                                const last = prev[prev.length - 1];
                                if (last?.speaker === 'user') {
                                    return [...prev.slice(0, -1), { speaker: 'user', text: last.text + text }];
                                }
                                return [...prev, { speaker: 'user', text }];
                            });
                        }
                        if (message.serverContent?.outputTranscription) {
                            const text = message.serverContent.outputTranscription.text;
                             setTranscript(prev => {
                                const last = prev[prev.length - 1];
                                if (last?.speaker === 'model') {
                                    return [...prev.slice(0, -1), { speaker: 'model', text: last.text + text }];
                                }
                                return [...prev, { speaker: 'model', text }];
                            });
                        }

                        const base64EncodedAudioString = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                        if (base64EncodedAudioString) {
                            setTutorStatus('SPEAKING');
                            nextStartTime = Math.max(nextStartTime, outputAudioContext.currentTime);
                            const audioBuffer = await decodeAudioData(decode(base64EncodedAudioString), outputAudioContext, 24000, 1);
                            const source = outputAudioContext.createBufferSource();
                            source.buffer = audioBuffer;
                            source.connect(outputAudioContext.destination);
                            source.addEventListener('ended', () => {
                                sources.delete(source);
                                if (sources.size === 0) {
                                    setTutorStatus('LISTENING');
                                }
                            });
                            source.start(nextStartTime);
                            nextStartTime += audioBuffer.duration;
                            sources.add(source);
                        }
                        
                        if (message.serverContent?.interrupted) {
                           for (const source of sources.values()) {
                                source.stop();
                                sources.delete(source);
                            }
                            nextStartTime = 0;
                            setTutorStatus('LISTENING');
                        }
                    },
                    onerror: (e: ErrorEvent) => {
                        console.error('Voice Tutor Error:', e);
                        setApiError(`Voice Tutor connection error: ${e.message}`);
                        stopVoiceTutor();
                        goToHome();
                    },
                    onclose: (e: CloseEvent) => {
                       console.log('Voice Tutor session closed.');
                       stopVoiceTutor();
                    },
                },
                config: {
                    responseModalities: [Modality.AUDIO],
                    speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
                    inputAudioTranscription: {},
                    outputAudioTranscription: {},
                    systemInstruction: `You are a friendly and encouraging AI voice tutor for a Grade ${grade} student studying the chapter "${topic}". Keep your responses concise and conversational. Guide the student through the topic by asking them questions and explaining concepts simply when they are unsure. Wait for them to finish speaking before you respond.`
                },
            });
            liveSessionRef.current = sessionPromise;
        } catch (error) {
            console.error('Failed to start voice tutor:', error);
            setApiError(error instanceof Error && error.name === 'NotAllowedError' ? 'Microphone access was denied. Please allow microphone access in your browser settings to use the Voice Tutor.' : 'Failed to access microphone.');
            setGameState(GameState.HOME_SCREEN);
        }
    }, [grade, topic, stopVoiceTutor, addLogEntry, goToHome]);

    useEffect(() => {
        return () => {
            if (gameState !== GameState.VOICE_TUTOR_SESSION && liveSessionRef.current) {
                stopVoiceTutor();
            }
        };
    }, [gameState, stopVoiceTutor]);

    // ====================================================================================
    // User Authentication
    // ====================================================================================

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        setAuthError('');
        const user = users.find(u => u.username === usernameInput && u.password === passwordInput);
        if (user) {
            setCurrentUserId(user.id);
            setGameState(GameState.HOME_SCREEN);
            setUsernameInput('');
            setPasswordInput('');
            addLogEntry('USER_LOGIN', {});
        } else {
            setAuthError('Invalid username or password.');
        }
    };

    const handleRegister = (e: React.FormEvent) => {
        e.preventDefault();
        setAuthError('');
        if (users.some(u => u.username === usernameInput)) {
            setAuthError('Username already exists.');
            return;
        }
        if (!usernameInput || !passwordInput) {
            setAuthError('Username and password cannot be empty.');
            return;
        }
        const newUser: User = {
            id: generateUniqueId(),
            username: usernameInput,
            password: passwordInput,
            isAdmin: false,
            stats: {
                quizzesCompleted: 0,
                quizzesAttempted: 0,
                topicsMastered: [],
                totalScorePoints: 0,
                totalQuestionsAnswered: 0,
                timeSpentLearningInSeconds: 0,
                topicPerformance: {},
                badges: [],
            },
        };
        setUsers([...users, newUser]);
        setCurrentUserId(newUser.id);
        setGameState(GameState.HOME_SCREEN);
        setUsernameInput('');
        setPasswordInput('');
        addLogEntry('USER_REGISTERED', {});
    };

    const handleLogout = () => {
        addLogEntry('USER_LOGOUT', {});
        setCurrentUserId(null);
        setGameState(GameState.LOGIN_SCREEN);
        resetSelections();
    };

    const handleProfilePicUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files[0]) {
            const reader = new FileReader();
            reader.onload = (e) => {
                if (typeof e.target?.result === 'string') {
                    setEditingProfilePic(e.target.result);
                    setGameState(GameState.EDIT_PROFILE_PICTURE);
                }
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    };
    
    const handleSaveProfilePic = (dataUrl: string) => {
        if (!currentUserId || !currentUser) return;
        setUsers(prevUsers =>
            prevUsers.map(user =>
                user.id === currentUserId ? { ...user, profilePictureUrl: dataUrl } : user
            )
        );
        updateLeaderboard(currentUser.username, 0, dataUrl);
        setEditingProfilePic(null);
        setGameState(GameState.USER_PROFILE);
    };


    // ====================================================================================
    // RENDER LOGIC
    // ====================================================================================

    if (apiError) return <ApiErrorDisplay message={apiError} onDismiss={() => setApiError(null)} />;
    if (isLoading) return <FullScreenLoader message={loadingMessage} />;

    // FIX: Simplified condition to just check for currentUser. 
    // This fixes the type error and a bug where logged-in users saw the login screen on refresh.
    if (!currentUser) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-slate-900 p-4">
                <div className="w-full max-w-md bg-slate-800 p-8 rounded-2xl shadow-2xl border border-slate-700">
                    <div className="text-center mb-8">
                        <HomeScreenAtomIcon/>
                        <h1 className="text-4xl font-bold text-slate-200 mt-2">The Book of Curiosity</h1>
                        <p className="text-slate-400 mt-2">{showRegister ? 'Create a new account' : 'Welcome back, curious mind!'}</p>
                    </div>

                    <form onSubmit={showRegister ? handleRegister : handleLogin}>
                        <div className="mb-4">
                            <label className="block text-slate-400 text-sm font-bold mb-2" htmlFor="username">Username</label>
                            <input
                                id="username"
                                type="text"
                                value={usernameInput}
                                onChange={e => setUsernameInput(e.target.value)}
                                className="w-full px-3 py-2 text-slate-200 bg-slate-700 border border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                                placeholder="e.g., MarieCurieFan"
                            />
                        </div>
                        <div className="mb-6">
                            <label className="block text-slate-400 text-sm font-bold mb-2" htmlFor="password">Password</label>
                            <input
                                id="password"
                                type="password"
                                value={passwordInput}
                                onChange={e => setPasswordInput(e.target.value)}
                                className="w-full px-3 py-2 text-slate-200 bg-slate-700 border border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
                                placeholder="******************"
                            />
                        </div>
                        {authError && <p className="text-red-400 text-center mb-4">{authError}</p>}
                        <div className="flex items-center justify-between">
                            <ActionButton type="submit">{showRegister ? 'Register' : 'Login'}</ActionButton>
                            <button type="button" onClick={() => { setShowRegister(!showRegister); setAuthError(''); }} className="inline-block align-baseline font-bold text-sm text-cyan-400 hover:text-cyan-300">
                                {showRegister ? 'Already have an account?' : 'Create an account'}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        );
    }

    const renderContent = () => {
        const commonProps = { grade, topic };
        const mainContainerClasses = "container mx-auto max-w-5xl p-4 pt-24 md:pt-28";
        
        switch (gameState) {
            case GameState.HOME_SCREEN:
                const features = [
                    { title: 'Interactive Quiz', description: 'Test your knowledge with an endless supply of AI-generated questions.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>, onClick: () => startAppMode('quiz') },
                    { title: 'AI Doubt Solver', description: 'Stuck on a concept? Ask our AI tutor for a simple explanation.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>, onClick: () => startAppMode('doubt_solver') },
                    { title: 'AI Voice Tutor', description: 'Practice concepts by having a spoken conversation with an AI tutor.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>, onClick: () => startAppMode('voice_tutor') },
                    { title: 'Diagram Generator', description: 'Visualize complex topics with custom AI-generated diagrams.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>, onClick: () => startAppMode('diagram') },
                    { title: 'Printable Worksheet', description: 'Generate practice worksheets to solve offline.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>, onClick: () => startAppMode('worksheet') },
                    { title: 'Quick Study Notes', description: 'Get concise, easy-to-read notes on any chapter.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>, onClick: () => startAppMode('notes') },
                    { title: 'Concept Deep Dive', description: 'Go beyond the textbook with in-depth explanations.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>, onClick: () => startAppMode('deep_dive') },
                    { title: 'Virtual Lab', description: 'Simulate experiments with step-by-step visual guidance.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547a2 2 0 00-.547 1.806l.477 2.387a6 6 0 00.517 3.86l.158.318a6 6 0 00.517 3.86l2.387.477a2 2 0 001.806-.547a2 2 0 00.547-1.806l-.477-2.387a6 6 0 00-.517-3.86l-.158-.318a6 6 0 01-.517-3.86l-2.387-.477a2 2 0 01-.547-1.806l.477-2.387a6 6 0 013.86-.517l.318.158a6 6 0 003.86-.517l2.387-.477a2 2 0 011.806.547a2 2 0 01.547 1.806l-.477 2.387a6 6 0 01-3.86.517l-.318.158a6 6 0 00-3.86.517l-2.387.477a2 2 0 00-1.806.547a2 2 0 00-.547 1.806l.477 2.387a6 6 0 00.517 3.86l.158.318a6 6 0 00.517 3.86l2.387.477a2 2 0 001.806-.547a2 2 0 00.547-1.806l-.477-2.387a6 6 0 00-.517-3.86l-.158-.318a6 6 0 01-.517-3.86l-2.387-.477a2 2 0 01-.547-1.806z" /></svg>, onClick: () => startAppMode('virtual_lab') },
                    { title: 'Real World Links', description: 'See how science applies to everyday life around you.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2h10a2 2 0 002-2v-1a2 2 0 012-2h1.945M7.757 14.757l.707-.707M16.243 14.757l-.707-.707M12 20.05V17.5M12 3.95v-2.5" /></svg>, onClick: () => startAppMode('real_world_connections') },
                    { title: 'Chat with History', description: 'Talk to simulations of science\'s greatest minds.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" /></svg>, onClick: () => startAppMode('historical_chat') },
                    { title: 'AI Story Weaver', description: 'Turn any science concept into a fun, educational story.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>, onClick: () => startAppMode('ai_story_weaver') },
                    { title: 'My Profile', description: 'View your progress, stats, and earned badges.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>, onClick: () => startAppMode('profile') },
                    { title: 'Leaderboard', description: 'See who the top curious minds are!', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>, onClick: () => startAppMode('leaderboard') },
                ];
                if (currentUser.isAdmin) {
                    features.push({ title: 'Admin Panel', description: 'View application activity and user data.', icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-full w-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>, onClick: () => startAppMode('admin') });
                }
                return (
                    <div className={mainContainerClasses}>
                        <PageHeader title={`Welcome, ${currentUser.username}!`} subtitle="What would you like to explore today?" />
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                            {features.map(feature => <FeatureCard key={feature.title} {...feature} />)}
                        </div>
                    </div>
                );
            case GameState.GRADE_SELECTION:
                return (
                    <div className={mainContainerClasses}>
                        <PageHeader title="Select Your Grade" subtitle="Let's find the right topics for you." />
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 max-w-4xl mx-auto">
                            {[6, 7, 8, 9, 10].map((g) => (
                                <SelectionButton key={g} onClick={() => selectGrade(g as Grade)} className="text-2xl font-bold text-center py-8">{g}</SelectionButton>
                            ))}
                        </div>
                    </div>
                );
            case GameState.TOPIC_SELECTION:
                return (
                    <div className={mainContainerClasses}>
                        <PageHeader title="Select a Topic" grade={grade!} />
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {(CHAPTERS_BY_GRADE[grade!] || []).map(t => (
                                <SelectionButton key={t} onClick={() => selectTopic(t)} className="text-lg">{t}</SelectionButton>
                            ))}
                        </div>
                    </div>
                );
            case GameState.QUIZ_DIFFICULTY_SELECTION:
            case GameState.WORKSHEET_DIFFICULTY_SELECTION:
                return (
                     <div className={mainContainerClasses}>
                        <PageHeader title={`Select ${appMode === 'quiz' ? 'Quiz' : 'Worksheet'} Difficulty`} {...commonProps} />
                        <div className="flex flex-col md:flex-row justify-center items-center gap-6">
                            {(['Easy', 'Medium', 'Hard'] as Difficulty[]).map(d => (
                                <ActionButton key={d} onClick={() => {
                                    setDifficulty(d);
                                    setGameState(appMode === 'quiz' ? GameState.QUIZ_COUNT_SELECTION : GameState.WORKSHEET_COUNT_SELECTION);
                                }} className="w-full md:w-48 text-2xl py-6">{d}</ActionButton>
                            ))}
                        </div>
                    </div>
                );
             case GameState.QUIZ_COUNT_SELECTION:
             case GameState.WORKSHEET_COUNT_SELECTION:
                const isQuiz = gameState === GameState.QUIZ_COUNT_SELECTION;
                return (
                    <div className={mainContainerClasses}>
                         <PageHeader title="Number of Questions" {...commonProps} subtitle={`Difficulty: ${difficulty}`} />
                        <div className="flex justify-center items-center gap-4 mb-8">
                             {[5, 10, 15, 20].map(count => (
                                <button key={count} onClick={() => setQuestionCount(count)} className={`w-16 h-16 flex items-center justify-center font-bold text-2xl rounded-full border-2 transition-colors ${questionCount === count ? 'bg-cyan-500 border-cyan-400 text-white' : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-cyan-500'}`}>{count}</button>
                            ))}
                        </div>
                         <div className="text-center">
                            <ActionButton onClick={() => isQuiz ? setGameState(GameState.QUIZ_TIMER_SELECTION) : handleGenerateQuiz(difficulty!, questionCount, 0, 'worksheet')}>Next</ActionButton>
                        </div>
                    </div>
                );
            case GameState.QUIZ_TIMER_SELECTION:
                 return (
                    <div className={mainContainerClasses}>
                         <PageHeader title="Time Per Question" {...commonProps} subtitle={`Difficulty: ${difficulty} | Questions: ${questionCount}`} />
                        <div className="flex justify-center items-center gap-4 mb-8">
                             {[0, 15, 30, 60].map(time => (
                                <button key={time} onClick={() => setTimePerQuestion(time)} className={`px-6 py-4 flex items-center justify-center font-bold text-xl rounded-lg border-2 transition-colors ${timePerQuestion === time ? 'bg-cyan-500 border-cyan-400 text-white' : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-cyan-500'}`}>{time === 0 ? 'Unlimited' : `${time}s`}</button>
                            ))}
                        </div>
                         <div className="text-center">
                            <ActionButton onClick={() => handleGenerateQuiz(difficulty!, questionCount, timePerQuestion, 'quiz')}>Start Quiz</ActionButton>
                        </div>
                    </div>
                );
            case GameState.QUIZ_IN_PROGRESS:
                const currentQuestion = questions[currentQuestionIndex];
                const userAnswer = userAnswers[currentQuestionIndex];
                return (
                     <div className={mainContainerClasses}>
                        <PageHeader title={`${appMode === 'quiz' ? 'Quiz' : 'Worksheet'} in Progress`} {...commonProps} />
                        <div className="bg-slate-800 p-6 md:p-8 rounded-xl shadow-lg border border-slate-700">
                             <div className="flex justify-between items-center mb-4 text-slate-400">
                                <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
                                {timePerQuestion > 0 && <span className="font-bold text-2xl text-cyan-400">{timeLeft}s</span>}
                             </div>
                             {timePerQuestion > 0 && <div className="w-full bg-slate-700 rounded-full h-2.5 mb-6"><div className="bg-cyan-500 h-2.5 rounded-full" style={{ width: `${(timeLeft / timePerQuestion) * 100}%`, transition: 'width 1s linear' }}></div></div>}
                            <h2 className="text-2xl md:text-3xl text-slate-200 mb-6">{currentQuestion.question}</h2>
                            {currentQuestion.type === 'Assertion/Reason' && <p className="text-lg text-slate-300 italic mb-6"><strong>Reason:</strong> {currentQuestion.reason}</p>}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                {currentQuestion.options.map(option => {
                                    const isSelected = userAnswer === option;
                                    const isCorrect = currentQuestion.answer === option;
                                    let buttonClass = 'bg-slate-700 hover:bg-slate-600';
                                    if(userAnswer) {
                                        if(isSelected && !isCorrect) buttonClass = 'bg-red-500/80';
                                        if(isCorrect) buttonClass = 'bg-green-500/80';
                                    }
                                    return <button key={option} onClick={() => handleAnswer(option)} disabled={!!userAnswer} className={`w-full text-left p-4 rounded-lg text-lg transition-all duration-300 border-2 border-transparent ${buttonClass}`}>{option}</button>
                                })}
                            </div>
                            {userAnswer && (
                                <div className="mt-6 p-4 bg-slate-700/50 rounded-lg">
                                    <h3 className="font-bold text-xl text-cyan-400 mb-2">Explanation</h3>
                                    <p className="text-slate-300">{currentQuestion.explanation}</p>
                                </div>
                            )}
                        </div>
                    </div>
                );
            case GameState.QUIZ_SCORE:
                 return (
                     <div className={mainContainerClasses}>
                        <PageHeader title="Quiz Complete!" {...commonProps} />
                        <div className="text-center bg-slate-800 p-8 rounded-xl shadow-lg border border-slate-700">
                             <h2 className="text-2xl text-slate-300 mb-2">Your Score</h2>
                             <p className="text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-300 mb-8">{score} <span className="text-4xl text-slate-400">/ {questions.length}</span></p>
                             <ActionButton onClick={goToHome}>Back to Home</ActionButton>
                        </div>
                        <Modal isOpen={showBadgeModal} onClose={() => setShowBadgeModal(false)} title="New Badge Unlocked!">
                            {newBadges.map(badge => (
                                <div key={badge.id} className="flex items-center p-4 rounded-lg bg-slate-700 mb-4">
                                    <div className="w-16 h-16 mr-4 text-yellow-400">{BADGE_DEFINITIONS[badge.id].icon}</div>
                                    <div>
                                        <h3 className="text-xl font-bold text-slate-200">{badge.name}</h3>
                                        <p className="text-slate-400">{badge.description}</p>
                                    </div>
                                </div>
                            ))}
                            <div className="text-right mt-4">
                                <ActionButton onClick={() => setShowBadgeModal(false)}>Awesome!</ActionButton>
                            </div>
                        </Modal>
                    </div>
                );
            case GameState.LANGUAGE_SELECTION:
                return (
                     <div className={mainContainerClasses}>
                        <PageHeader title="Select Language" {...commonProps} />
                        <div className="flex flex-col items-center gap-4 max-w-md mx-auto">
                            {(['English', 'English+Hindi', 'English+Tamil', 'English+Telugu', 'English+Kannada', 'English+Malayalam'] as Language[]).map(lang => (
                                <SelectionButton key={lang} onClick={() => startDoubtSolver(lang)}>{lang}</SelectionButton>
                            ))}
                        </div>
                    </div>
                );
            case GameState.DOUBT_SOLVER:
                return (
                     <div className="flex flex-col h-screen pt-20">
                         <PageHeader title="AI Doubt Solver" {...commonProps} />
                         <div className="flex-grow overflow-y-auto p-4 space-y-4">
                            {doubtSolverMessages.map((msg, index) => (
                                <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-xl p-4 rounded-2xl ${msg.role === 'user' ? 'bg-cyan-600 text-white rounded-br-none' : 'bg-slate-700 text-slate-200 rounded-bl-none'}`}>
                                        <p>{msg.text}</p>
                                    </div>
                                </div>
                            ))}
                            {isThinking && <div className="flex justify-start"><div className="p-4 rounded-2xl bg-slate-700 rounded-bl-none"><LoadingSpinner /></div></div>}
                         </div>
                         <div className="p-4 bg-slate-900 border-t border-slate-700">
                             <form onSubmit={(e) => { e.preventDefault(); const form = e.target as HTMLFormElement; const input = form.elements.namedItem('message') as HTMLInputElement; sendDoubtSolverMessage(input.value); input.value = ''; }} className="flex gap-4">
                                 <input type="text" name="message" placeholder="Ask your doubt..." className="flex-grow bg-slate-800 border border-slate-600 rounded-lg p-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500" />
                                 <ActionButton type="submit" disabled={isThinking}>Send</ActionButton>
                             </form>
                         </div>
                    </div>
                );
            case GameState.DIAGRAM_IDEAS_SELECTION:
                return (
                    <div className={mainContainerClasses}>
                         <PageHeader title="Choose a Diagram to Generate" {...commonProps} />
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {diagramIdeas.map(idea => (
                                <SelectionButton key={idea.id} onClick={() => handleGenerateDiagram(idea)}>
                                    <p className="text-lg text-slate-200">{idea.description}</p>
                                    <p className="text-xs text-slate-500 mt-2 truncate">Prompt: {idea.prompt}</p>
                                </SelectionButton>
                            ))}
                         </div>
                    </div>
                );
            case GameState.DIAGRAM_GENERATOR:
                return (
                    <div className={mainContainerClasses}>
                         <PageHeader title="Generated Diagram" subtitle={generatedDiagram?.description} {...commonProps} />
                         <div className="bg-white p-4 rounded-lg shadow-lg max-w-xl mx-auto">
                            {generatedDiagram?.image ? <img src={`data:image/png;base64,${generatedDiagram.image}`} alt={generatedDiagram.description} className="w-full h-auto" /> : <p>Image not available.</p>}
                         </div>
                         <div className="text-center mt-8">
                            <ActionButton onClick={goToHome}>Back to Home</ActionButton>
                         </div>
                    </div>
                );
            case GameState.WORKSHEET_DISPLAY:
                return (
                    <div className={mainContainerClasses + " printable-worksheet"}>
                        <PageHeader title="Worksheet" {...commonProps} />
                        <div className="no-print text-center mb-8">
                            <ActionButton onClick={() => window.print()}>Print Worksheet</ActionButton>
                        </div>
                        <div className="print-only text-center mb-8">
                            <h2 className="text-2xl">Name: _________________________ <span className="ml-8">Date: ____________</span></h2>
                        </div>
                        <div className="space-y-8">
                            {questions.map((q, index) => (
                                <div key={index} className="bg-slate-800 p-6 rounded-lg worksheet-question">
                                    <p className="text-lg font-semibold mb-4 text-slate-200">Q{index + 1}: {q.question}</p>
                                    {q.type === 'Assertion/Reason' && <p className="italic text-slate-300 mb-4"><strong>Reason:</strong> {q.reason}</p>}
                                    {q.type === 'MCQ' && (
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                            {q.options.map(opt => <div key={opt} className="p-2 text-slate-300"> ( ) {opt}</div>)}
                                        </div>
                                    )}
                                    {q.type === 'True/False' && (
                                        <div className="flex gap-4">
                                            <div className="p-2 text-slate-300">( ) True</div>
                                            <div className="p-2 text-slate-300">( ) False</div>
                                        </div>
                                    )}
                                    {q.type === 'Q&A' && <div className="mt-4 border-t-2 border-slate-600 print-only pt-4 h-24"></div>}
                                     <div className="no-print mt-4 p-4 bg-slate-700/50 rounded-lg">
                                        <p className="font-bold text-cyan-400">Answer: <span className="font-normal text-slate-300">{q.answer}</span></p>
                                        <p className="font-bold text-cyan-400 mt-2">Explanation: <span className="font-normal text-slate-300">{q.explanation}</span></p>
                                     </div>
                                </div>
                            ))}
                        </div>
                    </div>
                );
            case GameState.NOTES_DISPLAY:
                return (
                    <div className={mainContainerClasses}>
                         <PageHeader title="Study Notes" {...commonProps} />
                         <div className="bg-slate-800 p-6 md:p-8 rounded-lg shadow-lg border border-slate-700 space-y-6">
                            {notes.map(section => (
                                <div key={section.title}>
                                    <h2 className="text-2xl font-bold text-cyan-400 border-b-2 border-cyan-500/50 pb-2 mb-3">{section.title}</h2>
                                    <ul className="list-disc list-inside space-y-2 text-slate-300 text-lg">
                                        {section.points.map(point => <li key={point}>{point}</li>)}
                                    </ul>
                                </div>
                            ))}
                         </div>
                    </div>
                );
            case GameState.CONCEPT_DEEP_DIVE:
                 return (
                    <div className={mainContainerClasses}>
                         <PageHeader title="Concept Deep Dive" {...commonProps} />
                         <div className="prose prose-invert prose-lg max-w-none bg-slate-800 p-6 md:p-8 rounded-lg shadow-lg border border-slate-700">
                             <Suspense fallback={<LoadingSpinner/>}>
                                <Markdown remarkPlugins={[remarkGfm]}>{conceptExplanation}</Markdown>
                             </Suspense>
                         </div>
                    </div>
                );
            case GameState.VOICE_TUTOR_SESSION:
                 const statusIndicator = {
                    CONNECTING: { text: "Connecting...", color: "bg-yellow-500", pulse: true },
                    LISTENING: { text: "Listening...", color: "bg-green-500", pulse: true },
                    THINKING: { text: "Thinking...", color: "bg-cyan-500", pulse: true },
                    SPEAKING: { text: "Speaking...", color: "bg-blue-500", pulse: false },
                }[tutorStatus];
                return (
                    <div className="flex flex-col h-screen pt-20">
                        <PageHeader title="AI Voice Tutor" {...commonProps} />
                        <div className="flex-grow overflow-y-auto p-4 space-y-4">
                           {transcript.length === 0 && <p className="text-center text-slate-400 text-lg">Start speaking to begin your session...</p>}
                           {transcript.map((part, index) => (
                               <div key={index} className={`flex ${part.speaker === 'user' ? 'justify-end' : 'justify-start'}`}>
                                   <div className={`max-w-xl p-4 rounded-2xl ${part.speaker === 'user' ? 'bg-cyan-600 text-white rounded-br-none' : 'bg-slate-700 text-slate-200 rounded-bl-none'}`}>
                                       <p>{part.text}</p>
                                   </div>
                               </div>
                           ))}
                        </div>
                        <div className="p-4 bg-slate-900 border-t border-slate-700 text-center">
                           <div className="flex items-center justify-center gap-3 mb-4">
                                <span className={`relative flex h-3 w-3`}>
                                    <span className={`absolute inline-flex h-full w-full rounded-full ${statusIndicator.color} opacity-75 ${statusIndicator.pulse ? 'animate-ping' : ''}`}></span>
                                    <span className={`relative inline-flex rounded-full h-3 w-3 ${statusIndicator.color}`}></span>
                                </span>
                                <p className="text-slate-300 text-lg">{statusIndicator.text}</p>
                           </div>
                           <ActionButton onClick={stopVoiceTutor} className="bg-red-600 hover:bg-red-700 from-red-600 to-red-700">End Session</ActionButton>
                        </div>
                    </div>
                );
            case GameState.VIRTUAL_LAB_INPUT:
                 return (
                    <div className={mainContainerClasses}>
                         <PageHeader title="Virtual Lab" subtitle="What science experiment would you like to see?" />
                         <div className="max-w-2xl mx-auto">
                            <form onSubmit={e => { e.preventDefault(); handleGenerateVirtualLab(); }} className="flex flex-col items-center gap-4">
                                <textarea
                                    value={inputPrompt}
                                    onChange={e => setInputPrompt(e.target.value)}
                                    placeholder="e.g., How a volcano erupts, or the process of photosynthesis"
                                    className="w-full h-24 bg-slate-800 border-2 border-slate-700 rounded-lg p-3 text-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                                />
                                <ActionButton type="submit" disabled={!inputPrompt}>Animate Experiment</ActionButton>
                            </form>
                         </div>
                    </div>
                );
            case GameState.VIRTUAL_LAB_DISPLAY:
                return (
                     <div className={mainContainerClasses}>
                         <PageHeader title="Virtual Lab Experiment" subtitle={inputPrompt} />
                         <div className="space-y-8">
                            {virtualLabSteps.map((step, index) => (
                                <div key={index} className="flex flex-col md:flex-row items-center gap-6 bg-slate-800 p-6 rounded-lg border border-slate-700">
                                    <div className="flex-shrink-0 w-full md:w-64 h-64 bg-slate-700 rounded-md overflow-hidden">
                                        {step.image ? <img src={`data:image/png;base64,${step.image}`} alt={step.title} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center"><LoadingSpinner/></div>}
                                    </div>
                                    <div className="flex-grow">
                                        <h3 className="text-2xl font-bold text-cyan-400 mb-2">{index + 1}. {step.title}</h3>
                                        <p className="text-slate-300 text-lg">{step.description}</p>
                                    </div>
                                </div>
                            ))}
                         </div>
                     </div>
                );
            case GameState.REAL_WORLD_CONNECTIONS_DISPLAY:
                 return (
                     <div className={mainContainerClasses}>
                         <PageHeader title="Real World Connections" {...commonProps} />
                          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            {realWorldExamples.map((example, index) => (
                                <div key={index} className="bg-slate-800 rounded-lg overflow-hidden border border-slate-700 flex flex-col">
                                    <div className="w-full h-56 bg-slate-700">
                                        {example.image ? <img src={`data:image/png;base64,${example.image}`} alt={example.title} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center"><LoadingSpinner/></div>}
                                    </div>
                                    <div className="p-4 flex-grow">
                                        <h3 className="text-xl font-bold text-cyan-400 mb-2">{example.title}</h3>
                                        <p className="text-slate-300">{example.explanation}</p>
                                    </div>
                                </div>
                            ))}
                         </div>
                     </div>
                );
            case GameState.HISTORICAL_CHAT_SELECTION:
                return (
                    <div className={mainContainerClasses}>
                        <PageHeader title="Chat with a Legend of Science" subtitle="Choose who you would like to talk to." />
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                            {HISTORICAL_SCIENTISTS.map(s => (
                                <div key={s.id} onClick={() => startHistoricalChat(s)} className="bg-slate-800 p-4 rounded-lg text-center border border-slate-700 hover:border-cyan-500 cursor-pointer transition-colors">
                                    <img src={s.imageUrl} alt={s.name} className="w-24 h-24 rounded-full mx-auto mb-4 border-2 border-slate-600 bg-slate-700"/>
                                    <h3 className="text-xl font-bold text-slate-200">{s.name}</h3>
                                    <p className="text-slate-400 text-sm">{s.field}</p>
                                    <p className="text-slate-500 text-xs mt-1">{s.era}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                );
            case GameState.HISTORICAL_CHAT_SESSION:
                return (
                     <div className="flex flex-col h-screen pt-20">
                         <PageHeader title={`Chat with ${selectedScientist?.name}`} />
                         <div className="flex-grow overflow-y-auto p-4 space-y-4">
                            {historicalChatMessages.map((msg, index) => (
                                <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-xl p-4 rounded-2xl ${msg.role === 'user' ? 'bg-cyan-600 text-white rounded-br-none' : 'bg-slate-700 text-slate-200 rounded-bl-none'}`}>
                                        <p>{msg.text}</p>
                                    </div>
                                </div>
                            ))}
                            {isThinking && <div className="flex justify-start"><div className="p-4 rounded-2xl bg-slate-700 rounded-bl-none"><LoadingSpinner /></div></div>}
                         </div>
                         <div className="p-4 bg-slate-900 border-t border-slate-700">
                             <form onSubmit={(e) => { e.preventDefault(); const form = e.target as HTMLFormElement; const input = form.elements.namedItem('message') as HTMLInputElement; sendHistoricalChatMessage(input.value); input.value = ''; }} className="flex gap-4">
                                 <input type="text" name="message" placeholder={`Ask ${selectedScientist?.name} a question...`} className="flex-grow bg-slate-800 border border-slate-600 rounded-lg p-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500" />
                                 <ActionButton type="submit" disabled={isThinking}>Send</ActionButton>
                             </form>
                         </div>
                    </div>
                );
            case GameState.AI_STORY_WEAVER_INPUT:
                  return (
                    <div className={mainContainerClasses}>
                         <PageHeader title="AI Story Weaver" subtitle="What science concept should be the star of our story?" />
                         <div className="max-w-2xl mx-auto">
                            <form onSubmit={e => { e.preventDefault(); handleGenerateAIStory(); }} className="flex flex-col items-center gap-4">
                                <textarea
                                    value={inputPrompt}
                                    onChange={e => setInputPrompt(e.target.value)}
                                    placeholder="e.g., A water molecule's journey through the water cycle, or a brave little electron in an electric circuit."
                                    className="w-full h-24 bg-slate-800 border-2 border-slate-700 rounded-lg p-3 text-lg text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                                />
                                <ActionButton type="submit" disabled={!inputPrompt}>Write My Story</ActionButton>
                            </form>
                         </div>
                    </div>
                );
            case GameState.AI_STORY_WEAVER_DISPLAY:
                return (
                    <div className={mainContainerClasses}>
                         <PageHeader title="A Scientific Tale" subtitle={`Based on: "${inputPrompt}"`} />
                         <div className="prose prose-invert prose-lg max-w-none bg-slate-800 p-6 md:p-8 rounded-lg shadow-lg border border-slate-700">
                             <Suspense fallback={<LoadingSpinner/>}>
                                <Markdown remarkPlugins={[remarkGfm]}>{aiStory}</Markdown>
                             </Suspense>
                         </div>
                    </div>
                );
             case GameState.USER_PROFILE:
                return (
                    <div className={mainContainerClasses}>
                        <PageHeader title="My Profile" />
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div className="md:col-span-1 bg-slate-800 p-6 rounded-lg border border-slate-700 text-center flex flex-col items-center">
                                 <div className="relative mb-4 group">
                                    <img src={currentUser.profilePictureUrl || `https://api.dicebear.com/8.x/pixel-art/svg?seed=${currentUser.username}`} alt="Profile" className="w-32 h-32 rounded-full border-4 border-cyan-500 object-cover bg-slate-700"/>
                                    <label htmlFor="pfp-upload" className="absolute inset-0 bg-black bg-opacity-50 rounded-full flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                    </label>
                                    <input type="file" id="pfp-upload" className="hidden" accept="image/*" onChange={handleProfilePicUpload} />
                                 </div>
                                <h2 className="text-3xl font-bold text-slate-200">{currentUser.username}</h2>
                                {currentUser.isAdmin && <p className="text-cyan-400 font-semibold">(Administrator)</p>}
                                <p className="text-slate-400 mt-4">Total Score: <span className="font-bold text-white">{currentUser.stats.totalScorePoints}</span></p>
                            </div>
                            <div className="md:col-span-2 bg-slate-800 p-6 rounded-lg border border-slate-700">
                                <h3 className="text-2xl font-bold text-cyan-400 mb-4">My Stats</h3>
                                <div className="grid grid-cols-2 gap-4 text-slate-300">
                                    <div><span className="font-bold text-xl text-white">{currentUser.stats.quizzesAttempted}</span> Quizzes Attempted</div>
                                    <div><span className="font-bold text-xl text-white">{currentUser.stats.quizzesCompleted}</span> Quizzes Completed</div>
                                    <div><span className="font-bold text-xl text-white">{currentUser.stats.totalQuestionsAnswered}</span> Questions Answered</div>
                                    <div><span className="font-bold text-xl text-white">{Object.keys(currentUser.stats.topicPerformance).length}</span> Topics Explored</div>
                                </div>
                                {studyPlan && (
                                    <div className="mt-6 pt-4 border-t border-slate-700">
                                         <h3 className="text-2xl font-bold text-cyan-400 mb-2">Your Next Steps</h3>
                                         <div className="prose prose-invert max-w-none">
                                            <Suspense fallback={<LoadingSpinner/>}>
                                                <Markdown remarkPlugins={[remarkGfm]}>{studyPlan}</Markdown>
                                            </Suspense>
                                        </div>
                                    </div>
                                )}
                            </div>
                            <div className="md:col-span-3 bg-slate-800 p-6 rounded-lg border border-slate-700">
                                <h3 className="text-2xl font-bold text-cyan-400 mb-4">My Badges</h3>
                                {currentUser.stats.badges.length === 0 ? (
                                    <p className="text-slate-400">No badges earned yet. Keep taking quizzes to unlock them!</p>
                                ) : (
                                    <div className="flex flex-wrap gap-4">
                                        {currentUser.stats.badges.map(badge => (
                                            <div key={badge.id} className="flex flex-col items-center text-center p-2" title={`${badge.description} (Earned: ${new Date(badge.dateEarned).toLocaleDateString()})`}>
                                                <div className="w-16 h-16 text-yellow-400">{BADGE_DEFINITIONS[badge.id].icon}</div>
                                                <p className="text-sm font-semibold text-slate-300 mt-1">{badge.name}</p>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                );
            case GameState.EDIT_PROFILE_PICTURE:
                 return (
                    <div className={mainContainerClasses}>
                        <PageHeader title="Edit Profile Picture" />
                        <div className="max-w-md mx-auto">
                            <ProfilePictureEditor
                                imageUrl={editingProfilePic!}
                                onSave={handleSaveProfilePic}
                                onCancel={() => {
                                    setEditingProfilePic(null);
                                    setGameState(GameState.USER_PROFILE);
                                }}
                            />
                        </div>
                    </div>
                 );
            case GameState.ADMIN_PANEL:
                return (
                    <div className={mainContainerClasses}>
                        <PageHeader title="Admin Panel" />
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
                                 <h3 className="text-2xl font-bold text-cyan-400 mb-4">Users ({users.length})</h3>
                                 <div className="max-h-96 overflow-y-auto">
                                    {users.map(user => (
                                        <div key={user.id} className="flex items-center justify-between p-2 border-b border-slate-700">
                                            <div className="flex items-center gap-3">
                                                <img src={user.profilePictureUrl || `https://api.dicebear.com/8.x/pixel-art/svg?seed=${user.username}`} alt={user.username} className="w-8 h-8 rounded-full bg-slate-700" />
                                                <span className="text-slate-300">{user.username} {user.isAdmin ? '(Admin)' : ''}</span>
                                            </div>
                                            <span className="text-slate-400">Score: {user.stats.totalScorePoints}</span>
                                        </div>
                                    ))}
                                 </div>
                            </div>
                             <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
                                 <h3 className="text-2xl font-bold text-cyan-400 mb-4">Recent Activity</h3>
                                 <div className="max-h-96 overflow-y-auto">
                                     {activityLog.map(log => (
                                        <div key={log.id} className="p-2 border-b border-slate-700 text-slate-400">
                                            <p>{formatLogMessage(log)}</p>
                                            <p className="text-xs text-slate-500">{timeAgo(log.timestamp)}</p>
                                        </div>
                                     ))}
                                 </div>
                            </div>
                        </div>
                    </div>
                );
            case GameState.LEADERBOARD:
                return (
                    <div className={mainContainerClasses}>
                        <PageHeader title="Leaderboard" subtitle="Top 20 Curious Minds" />
                        <div className="bg-slate-800 p-2 md:p-6 rounded-lg border border-slate-700">
                             <div className="space-y-2">
                                {leaderboard.map((entry, index) => (
                                    <div key={entry.userId} className={`flex items-center p-3 rounded-lg ${index === 0 ? 'bg-yellow-500/20' : index === 1 ? 'bg-slate-500/20' : index === 2 ? 'bg-orange-600/20' : ''}`}>
                                        <div className="w-10 text-2xl font-bold text-center text-slate-400">{index + 1}</div>
                                        <img src={entry.profilePictureUrl || `https://api.dicebear.com/8.x/pixel-art/svg?seed=${entry.username}`} alt={entry.username} className="w-12 h-12 rounded-full mx-4 bg-slate-700" />
                                        <div className="flex-grow text-lg font-semibold text-slate-200">{entry.username}</div>
                                        <div className="text-xl font-bold text-cyan-400">{entry.score} pts</div>
                                    </div>
                                ))}
                             </div>
                        </div>
                    </div>
                );
            default:
                return (
                    <div className="text-center p-8">
                        <h1 className="text-2xl text-red-500">Error: Invalid Game State</h1>
                        <ActionButton onClick={goToHome}>Go Home</ActionButton>
                    </div>
                );
        }
    };

    return (
        <main className="min-h-screen bg-slate-900 text-slate-200 font-sans">
            {(gameState !== GameState.LOGIN_SCREEN && gameState !== GameState.VOICE_TUTOR_SESSION) && <HomeButton onClick={goToHome} />}
            {currentUser && <LogoutButton onClick={handleLogout} />}
            {renderContent()}
        </main>
    );
};

export default App;