import { GoogleGenAI, Type, HarmCategory, HarmBlockThreshold } from "@google/genai";
import { Grade, Difficulty, QuizQuestion, NoteSection, VirtualLabStep, RealWorldExample, AppMode, UserStats } from '../types';

let ai: GoogleGenAI | null = null;

export const initializeAiClient = () => {
    const apiKey = (typeof process === 'object' && process !== null && typeof process.env === 'object' && process.env !== null) ? process.env.API_KEY : undefined;
    
    if (!apiKey) {
        throw new Error("Configuration Error: The API_KEY is not available. Please ensure the execution environment is configured correctly.");
    }

    ai = new GoogleGenAI({ apiKey: apiKey });
};

export const getAiClient = (): GoogleGenAI => {
    if (!ai) {
        throw new Error("AI Client not initialized.");
    }
    return ai;
};

const safetySettings = [
  { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
  { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
];

interface GeminiDiagramIdea {
    prompt: string;
    description: string;
}

const diagramIdeasSchema = { type: Type.OBJECT, properties: { diagrams: { type: Type.ARRAY, description: "An array of exactly 8 diagram ideas.", items: { type: Type.OBJECT, properties: { prompt: { type: Type.STRING, description: "A detailed, descriptive prompt for an image generation model to create a clear, simple, black and white scientific diagram. The style should be like a textbook line drawing. For example: 'A simple line drawing of the water cycle, showing evaporation, condensation, precipitation, and collection. Use clear labels and arrows.'" }, description: { type: Type.STRING, description: "A simple, one-sentence explanation of the diagram for the student." } }, required: ['prompt', 'description'] } } }, required: ['diagrams'], };
const quizQuestionSchema = { type: Type.OBJECT, properties: { question: { type: Type.STRING }, reason: { type: Type.STRING }, options: { type: Type.ARRAY, items: { type: Type.STRING } }, answer: { type: Type.STRING }, explanation: { type: Type.STRING }, type: { type: Type.STRING }, }, required: ['question', 'options', 'answer', 'explanation', 'type'], };
const quizSchema = { type: Type.OBJECT, properties: { questions: { type: Type.ARRAY, items: quizQuestionSchema } }, required: ['questions'] };
const notesSchema = { type: Type.OBJECT, properties: { notes: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { title: { type: Type.STRING }, points: { type: Type.ARRAY, items: { type: Type.STRING } } }, required: ['title', 'points'] } } }, required: ['notes'] };
const virtualLabSchema = { type: Type.OBJECT, properties: { steps: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { title: { type: Type.STRING }, description: { type: Type.STRING }, imagePrompt: { type: Type.STRING } }, required: ['title', 'description', 'imagePrompt'] } } }, required: ['steps'] };
const realWorldSchema = { type: Type.OBJECT, properties: { examples: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { title: { type: Type.STRING }, explanation: { type: Type.STRING }, imagePrompt: { type: Type.STRING } }, required: ['title', 'explanation', 'imagePrompt'] } } }, required: ['examples'] };

export const generateDiagramIdeas = async (topic: string, grade: Grade): Promise<GeminiDiagramIdea[]> => {
    const prompt = `You are an expert science educator. Your task is to brainstorm 8 essential diagrams to help a Grade ${grade} student understand the chapter "${topic}" from the India NCERT Science textbook. For each of the 8 diagrams, provide two things: 1. A 'prompt': A detailed, effective prompt for an AI image generation model (like Imagen). The prompt must describe a simple, clear, scientific line drawing, like one found in a textbook. It should be black and white, with clear labels for all important parts. 2. A 'description': A very short, one-sentence explanation of what the diagram shows, written for the student. Generate exactly 8 diagram ideas.`;
    const response = await getAiClient().models.generateContent({ model: "gemini-2.5-flash", contents: prompt, config: { responseMimeType: "application/json", responseSchema: diagramIdeasSchema, safetySettings }, });
    const parsedResponse = JSON.parse(response.text.trim());
    if (!parsedResponse.diagrams || !Array.isArray(parsedResponse.diagrams) || parsedResponse.diagrams.length !== 8) { throw new Error("Received malformed diagram ideas from API. Expected 8 diagrams."); }
    return parsedResponse.diagrams as GeminiDiagramIdea[];
};

export const generateDiagramImage = async (prompt: string): Promise<string> => {
    const response = await getAiClient().models.generateImages({ model: 'imagen-4.0-generate-001', prompt: prompt, config: { numberOfImages: 1, outputMimeType: 'image/png', aspectRatio: '1:1' }, });
    if (!response.generatedImages || response.generatedImages.length === 0) throw new Error("Image generation returned no images.");
    return response.generatedImages[0].image.imageBytes;
};

export const generateQuizQuestions = async (topic: string, grade: Grade, difficulty: Difficulty, count: number, mode?: AppMode): Promise<QuizQuestion[]> => {
    const isWorksheet = mode === 'worksheet';
    const prompt = isWorksheet ? `You are an expert science educator creating a worksheet for a Grade ${grade} student studying the chapter "${topic}" from the India NCERT Science textbook. Generate exactly ${count} questions with difficulty: ${difficulty}. The questions should be a mix of the following types: "MCQ", "True/False", "Q&A", and "Assertion/Reason".\n- For "MCQ", provide a 'question', 4 distinct 'options', the correct 'answer', and a detailed 'explanation'. The 'type' must be "MCQ".\n- For "True/False", provide a 'question', 'options' must be ["True", "False"], the correct 'answer', and a detailed 'explanation'. The 'type' must be "True/False".\n- For "Q&A", provide a 'question' that requires a short typed answer. The 'options' array must be empty. Provide a model 'answer' and a detailed 'explanation'. The 'type' must be "Q&A".\n- For "Assertion/Reason", the 'question' field should contain the Assertion statement. The 'reason' field should contain the Reason statement. The 'options' must be ["Both Assertion and Reason are true, and Reason is the correct explanation of Assertion.", "Both Assertion and Reason are true, but Reason is not the correct explanation of Assertion.", "Assertion is true, but Reason is false.", "Assertion is false, but Reason is true."]. Provide the correct 'answer' from these options and a detailed 'explanation'. The 'type' must be "Assertion/Reason".\nEnsure you provide all required fields for each question type and populate the 'type' field correctly for all questions.` : `You are an expert science educator creating a quiz for a Grade ${grade} student studying the chapter "${topic}" from the India NCERT Science textbook. Generate exactly ${count} quiz questions with difficulty: ${difficulty}. Each question must be one of two types: "MCQ" or "True/False". Please distribute the question types. For MCQs, provide 4 distinct options. For True/False questions, the options must be exactly ["True", "False"]. For all questions, provide a 'question' text, the correct 'answer', and a detailed 'explanation'.`;
    const response = await getAiClient().models.generateContent({ model: "gemini-2.5-flash", contents: prompt, config: { responseMimeType: "application/json", responseSchema: quizSchema, safetySettings } });
    const parsedResponse = JSON.parse(response.text.trim());
    if (!parsedResponse.questions || !Array.isArray(parsedResponse.questions)) throw new Error("Received malformed quiz questions from API.");
    return parsedResponse.questions as QuizQuestion[];
};

export const generateNotes = async (topic: string, grade: Grade): Promise<NoteSection[]> => {
    const prompt = `You are an expert science educator. Create concise, easy-to-understand study notes for a Grade ${grade} student on the chapter "${topic}" from the India NCERT Science textbook. Break the chapter into logical sections. For each section, provide a clear title and key bullet points. Generate at least 3-5 sections.`;
    const response = await getAiClient().models.generateContent({ model: "gemini-2.5-flash", contents: prompt, config: { responseMimeType: "application/json", responseSchema: notesSchema, safetySettings } });
    const parsedResponse = JSON.parse(response.text.trim());
    if (!parsedResponse.notes || !Array.isArray(parsedResponse.notes)) throw new Error("Received malformed notes from API.");
    return parsedResponse.notes as NoteSection[];
};

export const generateConceptExplanation = async (topic: string, grade: Grade): Promise<string> => {
    const prompt = `You are an expert science educator. Explain the core concepts of the chapter "${topic}" for a Grade ${grade} student from the India NCERT Science textbook. Use simple language, analogies, and a provide real-world example. Structure the explanation with markdown for clarity.`;
    const response = await getAiClient().models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { safetySettings } });
    return response.text;
}

export const generateStudyPlan = async (stats: UserStats): Promise<string> => {
    const performanceSummary = Object.entries(stats.topicPerformance)
        .map(([topic, perf]) => `- ${topic}: ${Math.round((perf.correct / perf.total) * 100)}% accuracy (${perf.correct}/${perf.total} correct)`)
        .join('\n');
    const prompt = `You are a friendly and encouraging AI academic advisor. A student's recent quiz performance is as follows:\n${performanceSummary}\n\nThey have completed ${stats.quizzesCompleted} quizzes in total. Based on this, create a short, personalized study plan for their next session. The plan should:\n1. Acknowledge their strengths.\n2. Gently point out 1-2 topics they could improve on.\n3. Suggest concrete, actionable steps using the app's features (like "Try a 5-question Easy quiz on [topic]" or "Use the Doubt Solver to ask about [concept]").\n4. Keep it concise (2-3 paragraphs) and motivational. Use markdown for formatting.`;
    const response = await getAiClient().models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { safetySettings } });
    return response.text;
};

export const generateVirtualLabSteps = async (prompt: string): Promise<Omit<VirtualLabStep, 'image'>[]> => {
    const apiPrompt = `Animate a science experiment for a student based on this request: "${prompt}". Break it down into 3-5 clear, simple steps. For each step, provide a 'title', a one-sentence 'description' of what's happening, and a detailed 'imagePrompt' for an AI image generator to create a corresponding visual. The image style should be a clear, simple, colorful digital illustration.`;
    const response = await getAiClient().models.generateContent({ model: 'gemini-2.5-flash', contents: apiPrompt, config: { responseMimeType: 'application/json', responseSchema: virtualLabSchema, safetySettings } });
    const parsed = JSON.parse(response.text.trim());
    if (!parsed.steps || !Array.isArray(parsed.steps)) throw new Error("API returned malformed lab steps.");
    return parsed.steps;
};

export const generateRealWorldExamples = async (topic: string): Promise<Omit<RealWorldExample, 'image'>[]> => {
    const prompt = `Show a student how the scientific concept "${topic}" applies in the real world. Provide 3 distinct examples. For each example, give a 'title', a simple 'explanation', and a detailed 'imagePrompt' for an AI image generator to create an illustrative, colorful photograph-style image.`;
    const response = await getAiClient().models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { responseMimeType: 'application/json', responseSchema: realWorldSchema, safetySettings } });
    const parsed = JSON.parse(response.text.trim());
    if (!parsed.examples || !Array.isArray(parsed.examples)) throw new Error("API returned malformed real-world examples.");
    return parsed.examples;
};

export const generateAIStory = async (prompt: string): Promise<string> => {
    const systemInstruction = `You are a master storyteller for young learners, weaving captivating and educational tales about science. Your stories should be imaginative, clear, and scientifically accurate for a middle-school audience.`;
    const fullPrompt = `Write a short story (about 300-400 words) based on the following idea: "${prompt}". The story must be scientifically educational and engaging. Use markdown for formatting paragraphs.`;
    const response = await getAiClient().models.generateContent({ model: 'gemini-2.5-flash', contents: fullPrompt, config: { systemInstruction, safetySettings } });
    return response.text;
};
